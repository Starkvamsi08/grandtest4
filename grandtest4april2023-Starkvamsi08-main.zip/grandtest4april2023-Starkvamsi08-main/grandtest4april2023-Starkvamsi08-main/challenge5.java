import java.util.Scanner;

public class challenge5{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();

        int countZeros = 0;
        int countOnes = 0;

        for (int i = 0; i < input.length(); i++) {
            if (input.charAt(i) == '0') {
                countZeros++;
            } else {
                countOnes++;
            }
        }

        if (countZeros == 1 || countOnes == 1) {
            System.out.println("Yes");
        } else {
            System.out.println("No");
        }

        scanner.close();
    }
}