import java.util.ArrayList;
import java.util.Scanner;
 
class Book {
    int book_id;
    String title;
    String author;
    double price;

    public Book(int book_id, String title, String author, double price) {
        this.book_id = book_id;
        this.title = title;
        this.author = author;
        this.price = price;
    }
}

class BookNotFoundException extends Exception {
    public BookNotFoundException(String message) {
        super(message);
    }
}

public class challenge1 {
    ArrayList<Book> books = new ArrayList<>();

    public void addBook(int book_id, String title, String author, double price) {
        books.add(new Book(book_id, title, author, price));
        System.out.println("Book added successfully.");
    }

    public double calculateTotalPrice() {
        double total = 0;
        for (Book book : books) {
            total += book.price;
        }
        return total;
    }

    public void removeBook(int book_id) {
        for (Book book : books) {
            if (book.book_id == book_id) {
                books.remove(book);
                System.out.println("Book removed successfully.");
                return;
            }
        }
        System.out.println("Book not found.");
    }

    public void updateBookPrice(int book_id, double newPrice) {
        for (Book book : books) {
            if (book.book_id == book_id) {
                book.price = newPrice;
                System.out.println("Book price updated successfully.");
                return;
            }
        }
        System.out.println("Book not found.");
    }

    public void searchBooksByAuthor(String author) throws BookNotFoundException {
        boolean found = false;
        for (Book book : books) {
            if (book.author.equalsIgnoreCase(author)) {
                System.out.println("Book ID: " + book.book_id + ", Title: " + book.title + ", Price: " + book.price);
                found = true;
            }
        }
        if (!found) {
            throw new BookNotFoundException("No books found for author: " + author);
        }
    }

    public void SearchBook(String Author) throws BookNotFoundException {
        boolean f = false;
        for (Book b : books) {
            if (b.author.equalsIgnoreCase(Author)) {
                System.out.println("Book Id: " + b.book_id + " ,Title: " + b.title + ", Price: " + b.price);
                f = true;
            }
        }
        if (!f) {
            throw new BookNotFoundException("No books are found");
        }
    }

    public static void main(String[] args) {
        challenge1 manager = new challenge1();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Select from Menu:");
            System.out.println("1. Add books");
            System.out.println("2. Calculate total price of all books");
            System.out.println("3. Remove a book by book_id");
            System.out.println("4. Update book price by book_id");
            System.out.println("5. Search books by author");
            System.out.println("6. Quit");

            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter book ID: ");
                    int bookId = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter title: ");
                    String title = scanner.nextLine();
                    System.out.print("Enter author: ");
                    String author = scanner.nextLine();
                    System.out.print("Enter price: ");
                    double price = scanner.nextDouble();
                    manager.addBook(bookId, title, author, price);
                    break;
                case 2:
                    double totalPrice = manager.calculateTotalPrice();
                    System.out.println("Total price of all books: " + totalPrice);
                    break;
                case 3:
                    System.out.print("Enter book ID to remove: ");
                    int removeId = scanner.nextInt();
                    manager.removeBook(removeId);
                    break;
                case 4:
                    System.out.print("Enter book ID to update price: ");
                    int updateId = scanner.nextInt();
                    System.out.print("Enter new price: ");
                    double newPrice = scanner.nextDouble();
                    manager.updateBookPrice(updateId, newPrice);
                    break;
                case 5:
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter author to search: ");
                    String searchAuthor = scanner.nextLine();
                    try {
                        manager.searchBooksByAuthor(searchAuthor);
                    } catch (BookNotFoundException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 6:
                    System.out.println("Exiting program.");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}